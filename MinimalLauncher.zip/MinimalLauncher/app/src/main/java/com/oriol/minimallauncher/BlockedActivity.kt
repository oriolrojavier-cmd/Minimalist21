package com.oriol.minimallauncher

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class BlockedActivity : AppCompatActivity() {

    private var blockedPackage: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_blocked)

        blockedPackage = intent.getStringExtra("blocked_package") ?: ""
        val label = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(blockedPackage, 0)
            ).toString()
        } catch (e: Exception) {
            blockedPackage
        }
        findViewById<TextView>(R.id.blockedAppName).text = label

        val prefs = PrefsManager(this)
        val btnUnlock = findViewById<Button>(R.id.btnUnlockPin)
        val pinHint = findViewById<TextView>(R.id.pinHint)

        if (prefs.hasPin()) {
            btnUnlock.setOnClickListener { showPinDialog(prefs) }
        } else {
            btnUnlock.visibility = View.GONE
            pinHint.visibility = View.VISIBLE
        }

        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
    }

    private fun showPinDialog(prefs: PrefsManager) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.enter_pin_title)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                val pin = input.text.toString()
                if (prefs.checkPin(pin)) {
                    prefs.unlockTemporarily(blockedPackage, minutes = 5)
                    Toast.makeText(this, R.string.unlocked_temp, Toast.LENGTH_SHORT).show()
                    AppRepository.launch(this, blockedPackage)
                    finish()
                } else {
                    Toast.makeText(this, R.string.pin_incorrect, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finish()
    }
}
