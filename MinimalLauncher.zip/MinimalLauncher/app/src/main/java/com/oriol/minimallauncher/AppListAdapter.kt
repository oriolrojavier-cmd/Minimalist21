package com.oriol.minimallauncher

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppListAdapter(
    private var apps: List<AppInfo>,
    private val onClick: (AppInfo) -> Unit,
    private val onLongClick: ((AppInfo) -> Unit)? = null
) : RecyclerView.Adapter<AppListAdapter.ViewHolder>() {

    class ViewHolder(val textView: TextView) : RecyclerView.ViewHolder(textView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_app, parent, false) as TextView
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.textView.text = app.label
        holder.textView.alpha = if (app.isBlocked) 0.35f else 1f
        holder.textView.setOnClickListener { onClick(app) }
        holder.textView.setOnLongClickListener {
            onLongClick?.invoke(app)
            true
        }
    }

    override fun getItemCount() = apps.size

    fun update(newApps: List<AppInfo>) {
        apps = newApps
        notifyDataSetChanged()
    }
}
