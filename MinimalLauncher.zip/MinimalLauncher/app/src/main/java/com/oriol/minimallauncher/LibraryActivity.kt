package com.oriol.minimallauncher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class LibraryActivity : AppCompatActivity() {

    private lateinit var adapter: AppListAdapter
    private var allApps: List<AppInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerLibrary)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = AppListAdapter(
            emptyList(),
            onClick = { app ->
                if (!app.isBlocked) AppRepository.launch(this, app.packageName)
            },
            onLongClick = { app -> showAppMenu(app) }
        )
        recyclerView.adapter = adapter

        findViewById<EditText>(R.id.searchBox).addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filter(s?.toString().orEmpty())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        findViewById<Button>(R.id.btnEnableBlocking).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnSetPin).setOnClickListener { showSetPinDialog() }

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    private fun loadApps() {
        allApps = AppRepository.getLaunchableApps(this)
        adapter.update(allApps)
    }

    private fun filter(query: String) {
        val filtered = if (query.isBlank()) allApps
        else allApps.filter { it.label.contains(query, ignoreCase = true) }
        adapter.update(filtered)
    }

    private fun showAppMenu(app: AppInfo) {
        val mainLabel = if (app.isMain) getString(R.string.unmark_main) else getString(R.string.mark_main)
        val blockLabel = if (app.isBlocked) getString(R.string.unblock_app) else getString(R.string.block_app)
        val options = arrayOf(mainLabel, blockLabel)

        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options) { _, which ->
                val prefs = PrefsManager(this)
                when (which) {
                    0 -> prefs.toggleMain(app.packageName)
                    1 -> prefs.toggleBlocked(app.packageName)
                }
                loadApps()
            }
            .show()
    }

    private fun showSetPinDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.new_pin_title)
            .setView(input)
            .setPositiveButton(R.string.save) { _, _ ->
                val pin = input.text.toString()
                if (pin.length < 4) {
                    Toast.makeText(this, R.string.pin_too_short, Toast.LENGTH_SHORT).show()
                } else {
                    PrefsManager(this).setPin(pin)
                    Toast.makeText(this, R.string.pin_saved, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
