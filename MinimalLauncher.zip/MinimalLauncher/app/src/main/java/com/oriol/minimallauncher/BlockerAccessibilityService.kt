package com.oriol.minimallauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class BlockerAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        // Ignora las pantallas de nuestro propio launcher
        if (pkg == packageName) return

        val prefs = PrefsManager(applicationContext)
        if (prefs.shouldBlock(pkg)) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            val intent = Intent(this, BlockedActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("blocked_package", pkg)
            }
            startActivity(intent)
        }
    }

    override fun onInterrupt() {}
}
