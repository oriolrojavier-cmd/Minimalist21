package com.oriol.minimallauncher

data class AppInfo(
    val label: String,
    val packageName: String,
    var isMain: Boolean = false,
    var isBlocked: Boolean = false
)
