package com.oriol.minimallauncher

import android.content.Context
import java.security.MessageDigest

class PrefsManager(context: Context) {

    private val prefs = context.getSharedPreferences("minimal_launcher_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_MAIN = "main_apps"
        private const val KEY_BLOCKED = "blocked_apps"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_UNLOCK_PREFIX = "unlock_until_"
        private const val KEY_WEATHER_TEXT = "weather_text"
        private const val KEY_WEATHER_TIME = "weather_time"

        // Paquetes habituales de redes sociales, sugeridos por defecto.
        // El usuario puede añadir o quitar cualquiera desde la Biblioteca.
        val DEFAULT_BLOCKED = setOf(
            "com.instagram.android",
            "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill",
            "com.facebook.katana",
            "com.twitter.android",
            "com.snapchat.android",
            "com.reddit.frontpage",
            "com.pinterest"
        )
    }

    private fun isFirstRun(): Boolean = !prefs.contains(KEY_BLOCKED)

    fun getMainApps(): Set<String> = prefs.getStringSet(KEY_MAIN, emptySet()) ?: emptySet()

    fun getBlockedApps(): Set<String> {
        if (isFirstRun()) {
            prefs.edit().putStringSet(KEY_BLOCKED, DEFAULT_BLOCKED).apply()
            return DEFAULT_BLOCKED
        }
        return prefs.getStringSet(KEY_BLOCKED, emptySet()) ?: emptySet()
    }

    fun isMain(pkg: String) = getMainApps().contains(pkg)

    fun isBlocked(pkg: String) = getBlockedApps().contains(pkg)

    // Bloqueada Y sin un desbloqueo temporal activo
    fun shouldBlock(pkg: String): Boolean = isBlocked(pkg) && !isTemporarilyUnlocked(pkg)

    fun toggleMain(pkg: String) {
        val set = getMainApps().toMutableSet()
        if (!set.remove(pkg)) set.add(pkg)
        prefs.edit().putStringSet(KEY_MAIN, set).apply()
    }

    fun toggleBlocked(pkg: String) {
        val set = getBlockedApps().toMutableSet()
        if (!set.remove(pkg)) set.add(pkg)
        prefs.edit().putStringSet(KEY_BLOCKED, set).apply()
        // Si se bloquea, no tiene sentido que siga como principal
        if (set.contains(pkg)) {
            val main = getMainApps().toMutableSet()
            if (main.remove(pkg)) {
                prefs.edit().putStringSet(KEY_MAIN, main).apply()
            }
        }
    }

    // ---- PIN de desbloqueo puntual ----

    fun hasPin(): Boolean = prefs.contains(KEY_PIN_HASH)

    fun setPin(pin: String) {
        prefs.edit().putString(KEY_PIN_HASH, sha256(pin)).apply()
    }

    fun checkPin(pin: String): Boolean {
        val stored = prefs.getString(KEY_PIN_HASH, null) ?: return false
        return stored == sha256(pin)
    }

    fun unlockTemporarily(pkg: String, minutes: Int = 5) {
        val until = System.currentTimeMillis() + minutes * 60_000L
        prefs.edit().putLong(KEY_UNLOCK_PREFIX + pkg, until).apply()
    }

    fun isTemporarilyUnlocked(pkg: String): Boolean {
        val until = prefs.getLong(KEY_UNLOCK_PREFIX + pkg, 0L)
        return System.currentTimeMillis() < until
    }

    private fun sha256(text: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(text.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // ---- Caché del tiempo (para no pedirlo constantemente) ----

    fun getWeatherText(): String? = prefs.getString(KEY_WEATHER_TEXT, null)

    fun isWeatherFresh(): Boolean {
        val last = prefs.getLong(KEY_WEATHER_TIME, 0L)
        return System.currentTimeMillis() - last < 20 * 60_000L // 20 minutos
    }

    fun saveWeather(text: String) {
        prefs.edit()
            .putString(KEY_WEATHER_TEXT, text)
            .putLong(KEY_WEATHER_TIME, System.currentTimeMillis())
            .apply()
    }
}
