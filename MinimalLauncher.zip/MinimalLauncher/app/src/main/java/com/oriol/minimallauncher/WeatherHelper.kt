package com.oriol.minimallauncher

import android.location.Location
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Usa la API pública y gratuita de Open-Meteo (no requiere clave de API)
 * para obtener la temperatura y condición actuales a partir de coordenadas.
 */
object WeatherHelper {

    fun fetchCurrentWeather(location: Location): Pair<Double, String>? {
        return try {
            val url = URL(
                "https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}" +
                    "&longitude=${location.longitude}&current_weather=true"
            )
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.requestMethod = "GET"

            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()

            val current = JSONObject(body).getJSONObject("current_weather")
            val temp = current.getDouble("temperature")
            val code = current.getInt("weathercode")
            temp to describeCode(code)
        } catch (e: Exception) {
            null
        }
    }

    private fun describeCode(code: Int): String = when (code) {
        0 -> "Despejado"
        1, 2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Niebla"
        51, 53, 55, 56, 57 -> "Llovizna"
        61, 63, 65, 66, 67 -> "Lluvia"
        71, 73, 75, 77 -> "Nieve"
        80, 81, 82 -> "Chubascos"
        85, 86 -> "Chubascos de nieve"
        95 -> "Tormenta"
        96, 99 -> "Tormenta con granizo"
        else -> "—"
    }
}
