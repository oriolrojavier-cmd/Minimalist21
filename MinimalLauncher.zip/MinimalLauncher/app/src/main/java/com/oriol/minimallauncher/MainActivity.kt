package com.oriol.minimallauncher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyHint: TextView
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView
    private lateinit var weatherText: TextView
    private lateinit var adapter: AppListAdapter

    private val handler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 1000)
        }
    }

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) loadWeather() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerMain)
        emptyHint = findViewById(R.id.emptyHint)
        clockText = findViewById(R.id.clockText)
        dateText = findViewById(R.id.dateText)
        weatherText = findViewById(R.id.weatherText)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = AppListAdapter(emptyList(), onClick = { app ->
            if (app.isBlocked) {
                Toast.makeText(this, getString(R.string.blocked_message), Toast.LENGTH_SHORT).show()
            } else {
                AppRepository.launch(this, app.packageName)
            }
        })
        recyclerView.adapter = adapter

        findViewById<Button>(R.id.btnLibrary).setOnClickListener {
            startActivity(Intent(this, LibraryActivity::class.java))
        }

        weatherText.text = PrefsManager(this).getWeatherText().orEmpty()
    }

    override fun onResume() {
        super.onResume()
        refreshMainApps()
        updateClock()
        requestWeather()
    }

    override fun onStart() {
        super.onStart()
        handler.post(clockRunnable)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(clockRunnable)
    }

    private fun updateClock() {
        val now = Date()
        clockText.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        val dateFormat = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "ES"))
        dateText.text = dateFormat.format(now).replaceFirstChar { it.uppercase() }
    }

    private fun refreshMainApps() {
        val all = AppRepository.getLaunchableApps(this)
        val mainApps = all.filter { it.isMain && !it.isBlocked }
        adapter.update(mainApps)
        emptyHint.visibility = if (mainApps.isEmpty()) View.VISIBLE else View.GONE
    }

    // Pide el tiempo: usa la caché si es reciente, si no, intenta refrescarlo
    private fun requestWeather() {
        val prefs = PrefsManager(this)
        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            return
        }
        if (prefs.isWeatherFresh()) return
        loadWeather()
    }

    private fun loadWeather() {
        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasPermission) return

        val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        val location: Location? = try {
            locationManager.getProviders(true)
                .mapNotNull { locationManager.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
        } catch (e: SecurityException) {
            null
        }
        if (location == null) return

        Thread {
            val result = WeatherHelper.fetchCurrentWeather(location)
            runOnUiThread {
                if (result != null) {
                    val (temp, desc) = result
                    val text = "${temp.toInt()}°C · $desc"
                    weatherText.text = text
                    PrefsManager(this).saveWeather(text)
                }
            }
        }.start()
    }

    // Esta pantalla es el "home": no debe cerrarse con el botón atrás
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // No-op
    }
}
