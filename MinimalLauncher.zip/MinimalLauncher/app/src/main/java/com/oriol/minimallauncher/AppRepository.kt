package com.oriol.minimallauncher

import android.content.Context
import android.content.Intent

object AppRepository {

    fun getLaunchableApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        val prefs = PrefsManager(context)

        return resolveInfos
            .map { ri ->
                val pkg = ri.activityInfo.packageName
                AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    packageName = pkg,
                    isMain = prefs.isMain(pkg),
                    isBlocked = prefs.isBlocked(pkg)
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun launch(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }
}
