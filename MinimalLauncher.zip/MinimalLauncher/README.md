# Minimal Launcher

Launcher minimalista para Android/Pixel: lista de texto sin iconos, apps
principales en la pantalla de inicio (con reloj, fecha y tiempo), el resto en
"Biblioteca", y bloqueo activo de redes sociales con posibilidad de
desbloqueo puntual mediante PIN.

## Qué incluye

- **Inicio**: reloj, fecha y tiempo actual arriba; debajo, lista de texto con
  tus apps "principales".
- **Biblioteca**: todas las apps del dispositivo, en texto, con buscador.
  Mantén pulsada una app para marcarla "principal" o "bloqueada".
- **Bloqueo activo**: un servicio de accesibilidad cierra al instante
  cualquier app bloqueada, venga de donde venga (icono, notificación,
  widget...).
- **Desbloqueo con PIN**: al intentar abrir una app bloqueada, puedes
  introducir tu PIN para desbloquearla 5 minutos. El PIN se configura (y se
  puede cambiar cuando quieras) desde Biblioteca → "Configurar PIN".

---

## PASO A PASO: instalación completa

### 1. Instala Android Studio

Descárgalo gratis en `developer.android.com/studio` e instálalo (acepta las
opciones por defecto).

### 2. Activa el modo desarrollador en tu Pixel

1. Ajustes → Acerca del teléfono.
2. Toca 7 veces seguidas sobre "Número de compilación" hasta que diga
   "Ya eres desarrollador".
3. Vuelve a Ajustes → busca "Opciones de desarrollador" → actívalas.
4. Dentro, activa **"Depuración USB"**.

### 3. Abre el proyecto

1. Descomprime este `.zip`.
2. Abre Android Studio → **Open** → selecciona la carpeta `MinimalLauncher`.
3. Espera a que termine el "Gradle Sync" (la primera vez tarda unos minutos,
   descarga dependencias de internet). Si pregunta por el Gradle wrapper,
   acepta usar la distribución incluida en Android Studio.

### 4. Instálalo en el Pixel

1. Conecta el Pixel al ordenador por USB.
2. En el móvil aparecerá un aviso "¿Permitir depuración USB?" → acepta.
3. En Android Studio, arriba, comprueba que tu Pixel aparece seleccionado
   como dispositivo.
4. Pulsa el botón ▶ **Run**.

(Alternativa sin cable: **Build → Build App Bundle(s) / APK(s) → Build
APK(s)**, copia el `.apk` generado en `app/build/outputs/apk/debug/` al
teléfono por cualquier medio y ábrelo para instalarlo; puede que tengas que
permitir "instalar apps de orígenes desconocidos".)

### 5. Ponlo como launcher predeterminado

1. En el Pixel: **Ajustes → Apps → Apps predeterminadas → App de inicio**.
2. Elige **Minimal Launcher**.

### 6. Activa el bloqueo (permiso manual, obligatorio)

Android exige concederlo a mano, una sola vez:

1. Abre Minimal Launcher → **Biblioteca** → botón **"Activar bloqueo"**
   (te lleva directo a Ajustes de Accesibilidad).
2. Busca **"Minimal Launcher · Bloqueo de apps"** y actívalo, acepta el
   aviso.

### 7. Configura tu PIN de desbloqueo puntual

1. En **Biblioteca** → **"Configurar PIN"** → escribe un PIN de al menos
   4 dígitos → Guardar.
2. A partir de ahora, si intentas abrir una app bloqueada, verás el botón
   **"Desbloquear con PIN"**: al introducirlo correctamente, la app se abre
   y queda disponible 5 minutos (pasado ese tiempo vuelve a bloquearse).

### 8. Permite ver el tiempo (opcional)

La primera vez que abras la pantalla de inicio te pedirá permiso de
ubicación aproximada; acéptalo para ver la temperatura y condición actuales
(usa la API gratuita Open-Meteo, sin necesidad de registrarte en nada). Si
no concedes el permiso, simplemente no se mostrará esa línea.

> Nota: si justo después de instalar no aparece el tiempo, abre Google Maps
> una vez para que el sistema tenga una ubicación reciente guardada, y vuelve
> a abrir Minimal Launcher.

### 9. Organiza tus apps

En **Biblioteca**, mantén pulsada cualquier app para elegir:

- *Marcar como principal* → aparece en la pantalla de inicio.
- *Bloquear app* → no podrá abrirse salvo con tu PIN (se quita
  automáticamente de "principales").

Redes sociales bloqueadas por defecto la primera vez (editable cuando
quieras): Instagram, TikTok, Facebook, X/Twitter, Snapchat, Reddit,
Pinterest.

---

## Notas técnicas

- `minSdk 26` (Android 8.0+), `compileSdk 34`.
- La lista de apps usa `<queries>` (Android 11+), sin necesitar el permiso
  especial `QUERY_ALL_PACKAGES`.
- El bloqueo usa `AccessibilityService` + `GLOBAL_ACTION_HOME`.
- El PIN se guarda como hash SHA-256, nunca en texto plano.
- El tiempo se consulta a `api.open-meteo.com` (gratis, sin API key) usando
  la última ubicación conocida del dispositivo; se cachea 20 minutos para no
  hacer peticiones de más.
- No está pensado para publicarse en Google Play (un bloqueador vía
  accesibilidad suele requerir revisión especial de Google); es para
  instalación propia ("sideload") en tu Pixel.
